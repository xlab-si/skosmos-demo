// delay for the autocomplete widget's activation
var autocomplete_delay = 400;
// how many letters the user has to input before the widget activates.
var autocomplete_activation = 2;

// override this if you'd like to use the rest-api from some other Skosmos server instance.
var rest_base_url = 'rest/v1/';
